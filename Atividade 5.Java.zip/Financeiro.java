package Financeiro;

public class Financeiro {
	
	public Financeiro(int idPagamento, boolean pagEfetu, boolean cancelado, boolean processando) {
		super();
		this.idPagamento = idPagamento;
		PagEfetu = pagEfetu;
		this.setCancelado(cancelado);
		Processando = processando;
	}
	private int idPagamento;
	public int getIdPagamento() {
		return idPagamento;
	}
	public void setIdPagamento(int idPagamento) {
		this.idPagamento = idPagamento;
	}
	public boolean isPagEfetu() {
		return PagEfetu;
	}
	public void setPagEfetu(boolean pagEfetu) {
		PagEfetu = pagEfetu;
	}
	public boolean isProcessando() {
		return Processando;
	}
	public void setProcessando(boolean processando) {
		Processando = processando;
	}
	public boolean isCancelado() {
		return cancelado;
	}
	public void setCancelado(boolean cancelado) {
		this.cancelado = cancelado;
	}
	private boolean PagEfetu;
	private boolean cancelado;
	private boolean Processando;

}
