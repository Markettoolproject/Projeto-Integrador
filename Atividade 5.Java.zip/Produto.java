package Produto;

public class Produto {
	
	public char DescrProdut;
	public char marca;
	public int  tamanho;
	public float valorProdut; 
	
	public Produto(int codProdut, char descrProdut, char marca, int tamanho, float valorProdut) {
		super();
		this.codProdut = codProdut;
		DescrProdut = descrProdut;
		this.marca = marca;
		this.tamanho = tamanho;
		this.valorProdut = valorProdut;
	}
	public int  codProdut;
	public int getCodProdut() {
		return codProdut;
	}
	public void setCodProdut(int codProdut) {
		this.codProdut = codProdut;
	}
	public char getDescrProdut() {
		return DescrProdut;
	}
	public void setDescrProdut(char descrProdut) {
		DescrProdut = descrProdut;
	}
	public char getMarca() {
		return marca;
	}
	public void setMarca(char marca) {
		this.marca = marca;
	}
	public int getTamanho() {
		return tamanho;
	}
	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	public float getValorProdut() {
		return valorProdut;
	}
	public void setValorProdut(float valorProdut) {
		this.valorProdut = valorProdut;
	}
    public int cadastarProduto ( int codProdut) {
	 int codProdut1 = 0;
	return codProdut1;
    	
    }
    public int cadastarMarca (char marca) {
   	 int marca1 = 0;
   	return marca1;
    }
    public int cadastartamanho (int tamanho) {
      	 int tamanho1 = 0;
      	return tamanho1;
    }
    public int cadastarProduto (float valorProdut) {
     	 int Produt1 = 0;
     	return Produt1;
    }
}