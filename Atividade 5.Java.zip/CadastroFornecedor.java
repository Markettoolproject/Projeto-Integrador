package Cadastro;

public class CadastroFornecedor {
	
	private int codFornec;
	private char nomFornec;
	private char endFornec;
	private int  foneFornec;
	
	public CadastroFornecedor (int codFornec, char nomFornec, char endFornec, int foneFornec) {
		super();
		this.setCodFornec(codFornec);
		this.setNomFornec(nomFornec);
		this.setEndFornec(endFornec);
		this.setFoneFornec(foneFornec);
	}
	public int getCodFornec() {
		return codFornec;
	}
	public void setCodFornec(int codFornec) {
		this.codFornec = codFornec;
	}
	public char getNomFornec() {
		return nomFornec;
	}
	public void setNomFornec(char nomFornec) {
		this.nomFornec = nomFornec;
	}
	public char getEndFornec() {
		return endFornec;
	}
	public void setEndFornec(char endFornec) {
		this.endFornec = endFornec;
	}
	public int getFoneFornec() {
		return foneFornec;
	}
	public void setFoneFornec(int foneFornec) {
		this.foneFornec = foneFornec;
	}
	
	public int cadastarNome (char nomFornec ) {
		 int nomFornec1 = 0;
		return nomFornec1;
	 
     }
    public int enderecoFornec (char EndFornec) {
    	int EndFornec1 = 0;
    	return EndFornec1;
    }
    public int foneFornec ( char foneFornec) {
    	int foneFornec1 = 0;
    	return foneFornec1;
    }
    }


