package Pedido;

public class Pedido {
	
	public Pedido(int idPedido, float valPedido, int quantProduto) {
		super();
		this.idPedido = idPedido;
		this.valPedido = valPedido;
		this.quantProduto = quantProduto;
	}
	public int   idPedido;
	public int getIdPedido() {
		return idPedido;
	}
	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}
	public float getValPedido() {
		return valPedido;
	}
	public void setValPedido(float valPedido) {
		this.valPedido = valPedido;
	}
	public int getQuantProduto() {
		return quantProduto;
	}
	public void setQuantProduto(int quantProduto) {
		this.quantProduto = quantProduto;
	}
	public  float valPedido;
	public  int   quantProduto;
	
	

}
