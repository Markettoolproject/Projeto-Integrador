package Cadastro;

public class Cadastro_Cliente {
  
	private int codClient;
	private char nomClient;
	private char endClient;
	private int  foneClient;
	
	public Cadastro_Cliente(int codClient, char nomClient, char endClient, int foneClient) {
		super();
		this.setCodClient(codClient);
		this.setNomClient(nomClient);
		this.setEndClient(endClient);
		this.setFoneClient(foneClient);
	}
	public int getCodClient() {
		return codClient;
	}
	public void setCodClient(int codClient) {
		this.codClient = codClient;
	}
	public char getNomClient() {
		return nomClient;
	}
	public void setNomClient(char nomClient) {
		this.nomClient = nomClient;
	}
	public char getEndClient() {
		return endClient;
	}
	public void setEndClient(char endClient) {
		this.endClient = endClient;
	}
	public int getFoneClient() {
		return foneClient;
	}
	public void setFoneClient(int foneClient) {
		this.foneClient = foneClient;
	}
	
	public int cadastarNome (char nomClient ) {
		 int nomClient1 = 0;
		return nomClient1;
	 
     }
    public int enderecoCliente (char EndClient) {
    	int EndClient1 = 0;
    	return EndClient1;
    }
    public int foneClient ( char foneClient) {
    	int foneClient1 = 0;
    	return foneClient1;
    }
    }